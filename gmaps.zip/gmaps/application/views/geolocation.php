<html>
<head>
	<script type="text/javascript">
		var centreGot = false;
	</script>
	<?php echo $map['js']; ?>
</head>
<body><?php echo $map['html']; ?></body>
</html>